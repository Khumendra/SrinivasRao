# from django.conf.urls import url
# from Generic_Views_App import views
#
# urlpatterns = [
#     url(r'^data/$', views.GenericView_List.as_view()),
#     url(r'^data/(?P<pk>[0-9]+)/$', views.GenericView_Details.as_view())
# ]