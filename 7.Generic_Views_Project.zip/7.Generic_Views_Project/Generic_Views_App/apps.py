from django.apps import AppConfig


class GenericViewsAppConfig(AppConfig):
    name = 'Generic_Views_App'
