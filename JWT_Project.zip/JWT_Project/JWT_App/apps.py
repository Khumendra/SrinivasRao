from django.apps import AppConfig


class JwtAppConfig(AppConfig):
    name = 'JWT_App'
