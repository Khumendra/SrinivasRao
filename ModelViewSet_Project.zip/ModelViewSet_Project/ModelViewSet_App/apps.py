from django.apps import AppConfig


class ModelviewsetAppConfig(AppConfig):
    name = 'ModelViewSet_App'
