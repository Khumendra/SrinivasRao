from django.apps import AppConfig


class BasicAuthenticationAppConfig(AppConfig):
    name = 'Basic_Authentication_App'
