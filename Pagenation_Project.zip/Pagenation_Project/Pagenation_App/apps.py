from django.apps import AppConfig


class PagenationAppConfig(AppConfig):
    name = 'Pagenation_App'
