from django.apps import AppConfig


class MixinsAppConfig(AppConfig):
    name = 'MixIns_App'
