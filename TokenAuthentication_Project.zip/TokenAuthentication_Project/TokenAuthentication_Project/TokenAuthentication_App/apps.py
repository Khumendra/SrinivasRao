from django.apps import AppConfig


class TokenauthenticationAppConfig(AppConfig):
    name = 'TokenAuthentication_App'
