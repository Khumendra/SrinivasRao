from django.apps import AppConfig


class NestedSerializersAppConfig(AppConfig):
    name = 'Nested_Serializers_App'
