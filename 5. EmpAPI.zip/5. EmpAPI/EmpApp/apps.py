from django.apps import AppConfig


class EmpappConfig(AppConfig):
    name = 'EmpApp'
